/*
  # Create Financial Analytics Database Schema

  1. New Tables
    - `users`
      - `id` (uuid, primary key, references auth.users)
      - `email` (text, unique, not null)
      - `full_name` (text, not null)
      - `avatar_url` (text, optional)
      - `created_at` (timestamp with time zone, default now())
    
    - `transactions`
      - `id` (serial, primary key)
      - `date` (timestamp with time zone, not null)
      - `amount` (numeric(10,2), not null)
      - `category` (text, not null, check: Revenue or Expense)
      - `status` (text, not null, check: Paid or Pending)
      - `user_id` (text, not null)
      - `user_profile` (text, not null)
      - `description` (text, optional)
      - `created_at` (timestamp with time zone, default now())

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to manage their own data
    - Add policies for transactions that allow all authenticated users to read/write

  3. Sample Data
    - Insert sample users and transactions for demonstration
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  avatar_url text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on users table
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Create policies for users table
CREATE POLICY "Users can insert own profile"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can read own profile"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Create transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id serial PRIMARY KEY,
  date timestamptz NOT NULL,
  amount numeric(10,2) NOT NULL,
  category text NOT NULL CHECK (category IN ('Revenue', 'Expense')),
  status text NOT NULL CHECK (status IN ('Paid', 'Pending')),
  user_id text NOT NULL,
  user_profile text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on transactions table
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- Create policies for transactions table
CREATE POLICY "Users can insert transactions"
  ON transactions
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can read all transactions"
  ON transactions
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update transactions"
  ON transactions
  FOR UPDATE
  TO authenticated
  USING (true);

-- Insert sample data for demonstration
INSERT INTO transactions (date, amount, category, status, user_id, user_profile, description) VALUES
  ('2024-01-15 10:30:00+00', 2500.00, 'Revenue', 'Paid', 'john.doe@example.com', 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150', 'Website development project'),
  ('2024-01-14 14:20:00+00', 850.00, 'Expense', 'Paid', 'jane.smith@example.com', 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150', 'Office supplies and equipment'),
  ('2024-01-13 09:15:00+00', 3200.00, 'Revenue', 'Pending', 'mike.johnson@example.com', 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150', 'Mobile app development'),
  ('2024-01-12 16:45:00+00', 1200.00, 'Expense', 'Paid', 'sarah.wilson@example.com', 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=150', 'Marketing campaign costs'),
  ('2024-01-11 11:30:00+00', 4500.00, 'Revenue', 'Paid', 'david.brown@example.com', 'https://images.pexels.com/photos/697509/pexels-photo-697509.jpeg?auto=compress&cs=tinysrgb&w=150', 'E-commerce platform setup'),
  ('2024-01-10 13:20:00+00', 650.00, 'Expense', 'Pending', 'lisa.davis@example.com', 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150', 'Software licenses'),
  ('2024-01-09 08:45:00+00', 1800.00, 'Revenue', 'Paid', 'robert.miller@example.com', 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150', 'Consulting services'),
  ('2024-01-08 15:10:00+00', 950.00, 'Expense', 'Paid', 'emily.garcia@example.com', 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150', 'Travel expenses'),
  ('2024-01-07 12:00:00+00', 2200.00, 'Revenue', 'Pending', 'chris.martinez@example.com', 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150', 'Database optimization'),
  ('2024-01-06 10:30:00+00', 750.00, 'Expense', 'Paid', 'amanda.rodriguez@example.com', 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=150', 'Cloud hosting fees'),
  ('2024-01-05 14:15:00+00', 3800.00, 'Revenue', 'Paid', 'kevin.lee@example.com', 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=150', 'Custom software development'),
  ('2024-01-04 09:45:00+00', 1100.00, 'Expense', 'Pending', 'michelle.taylor@example.com', 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=150', 'Design tools subscription'),
  ('2024-01-03 16:20:00+00', 2900.00, 'Revenue', 'Paid', 'daniel.anderson@example.com', 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg?auto=compress&cs=tinysrgb&w=150', 'API integration project'),
  ('2024-01-02 11:10:00+00', 600.00, 'Expense', 'Paid', 'jessica.thomas@example.com', 'https://images.pexels.com/photos/1181424/pexels-photo-1181424.jpeg?auto=compress&cs=tinysrgb&w=150', 'Legal consultation'),
  ('2024-01-01 13:30:00+00', 5200.00, 'Revenue', 'Pending', 'ryan.jackson@example.com', 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=150', 'Enterprise solution deployment');