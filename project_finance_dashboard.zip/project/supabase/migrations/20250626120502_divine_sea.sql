/*
  # Financial Analytics Database Schema

  1. New Tables
    - `transactions`
      - `id` (serial, primary key)
      - `date` (timestamptz)
      - `amount` (decimal)
      - `category` (text - Revenue/Expense)
      - `status` (text - Paid/Pending)
      - `user_id` (text)
      - `user_profile` (text)
      - `description` (text, optional)
      - `created_at` (timestamptz)

    - `users` (extends auth.users)
      - `id` (uuid, primary key, references auth.users)
      - `email` (text)
      - `full_name` (text)
      - `avatar_url` (text, optional)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text NOT NULL,
  avatar_url text,
  created_at timestamptz DEFAULT now()
);

-- Create transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id serial PRIMARY KEY,
  date timestamptz NOT NULL,
  amount decimal(10,2) NOT NULL,
  category text NOT NULL CHECK (category IN ('Revenue', 'Expense')),
  status text NOT NULL CHECK (status IN ('Paid', 'Pending')),
  user_id text NOT NULL,
  user_profile text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- Create policies for users table
CREATE POLICY "Users can read own profile"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create policies for transactions table
CREATE POLICY "Users can read all transactions"
  ON transactions
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert transactions"
  ON transactions
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update transactions"
  ON transactions
  FOR UPDATE
  TO authenticated
  USING (true);

-- Insert sample data
INSERT INTO transactions (date, amount, category, status, user_id, user_profile, description) VALUES
  ('2024-01-15T08:34:12Z', 1500.00, 'Revenue', 'Paid', 'Matthew Peterson', 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Client payment'),
  ('2024-02-21T11:14:38Z', 1200.50, 'Expense', 'Paid', 'Floyd Miles', 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Office supplies'),
  ('2024-03-03T18:22:04Z', 300.75, 'Revenue', 'Pending', 'Jerome Bell', 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Consulting fee'),
  ('2024-04-10T05:03:11Z', 5000.00, 'Expense', 'Paid', 'Kathryn Murphy', 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Equipment purchase'),
  ('2024-05-20T12:01:45Z', 800.00, 'Revenue', 'Pending', 'Jacob Jones', 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Service fee'),
  ('2024-06-15T09:22:33Z', 2200.00, 'Revenue', 'Paid', 'Bessie Cooper', 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Project completion'),
  ('2024-07-08T14:55:21Z', 750.25, 'Expense', 'Paid', 'Ralph Edwards', 'https://images.pexels.com/photos/1674752/pexels-photo-1674752.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Marketing campaign'),
  ('2024-08-12T16:44:09Z', 1800.00, 'Revenue', 'Paid', 'Devon Lane', 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Monthly retainer'),
  ('2024-09-07T12:02:01Z', 3200.00, 'Revenue', 'Paid', 'Marvin McKinney', 'https://images.pexels.com/photos/1845534/pexels-photo-1845534.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Large contract'),
  ('2024-10-05T14:44:17Z', 1100.00, 'Expense', 'Paid', 'Theresa Webb', 'https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Software licenses'),
  ('2024-11-23T13:38:04Z', 2700.00, 'Revenue', 'Paid', 'Robert Fox', 'https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Annual contract'),
  ('2024-12-16T10:04:21Z', 3200.00, 'Expense', 'Pending', 'Jenny Wilson', 'https://images.pexels.com/photos/712513/pexels-photo-712513.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Year-end bonus'),
  ('2024-01-03T17:13:15Z', 1500.00, 'Revenue', 'Pending', 'Guy Hawkins', 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'New year project'),
  ('2024-02-27T15:17:48Z', 1100.00, 'Expense', 'Paid', 'Eleanor Pena', 'https://images.pexels.com/photos/1239288/pexels-photo-1239288.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Training expenses'),
  ('2024-03-19T11:28:52Z', 4500.00, 'Revenue', 'Paid', 'Brooklyn Simmons', 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Quarterly payment'),
  ('2024-04-25T13:45:30Z', 850.00, 'Expense', 'Paid', 'Savannah Nguyen', 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Travel expenses'),
  ('2024-05-11T16:22:18Z', 2100.00, 'Revenue', 'Paid', 'Courtney Henry', 'https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Maintenance contract'),
  ('2024-06-30T08:15:44Z', 1750.00, 'Revenue', 'Pending', 'Dianne Russell', 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Mid-year bonus'),
  ('2024-07-14T10:33:29Z', 950.00, 'Expense', 'Paid', 'Kristin Watson', 'https://images.pexels.com/photos/1499327/pexels-photo-1499327.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Office rent'),
  ('2024-08-22T14:57:12Z', 3800.00, 'Revenue', 'Paid', 'Cameron Williamson', 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1', 'Enterprise deal');