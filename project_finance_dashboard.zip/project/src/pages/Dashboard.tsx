import React, { useEffect, useState } from 'react';
import { DollarSign, TrendingUp, TrendingDown, Users } from 'lucide-react';
import { MetricCard } from '../components/Dashboard/MetricCard';
import { RevenueChart } from '../components/Dashboard/RevenueChart';
import { RecentTransactions } from '../components/Dashboard/RecentTransactions';
import { useTransactions } from '../hooks/useTransactions';

export function Dashboard() {
  const { transactions, loading } = useTransactions();
  const [metrics, setMetrics] = useState({
    totalRevenue: 0,
    totalExpenses: 0,
    netProfit: 0,
    totalTransactions: 0,
  });

  useEffect(() => {
    if (transactions.length > 0) {
      const revenue = transactions
        .filter(t => t.category === 'Revenue')
        .reduce((sum, t) => sum + t.amount, 0);
      
      const expenses = transactions
        .filter(t => t.category === 'Expense')
        .reduce((sum, t) => sum + t.amount, 0);

      setMetrics({
        totalRevenue: revenue,
        totalExpenses: expenses,
        netProfit: revenue - expenses,
        totalTransactions: transactions.length,
      });
    }
  }, [transactions]);

  return (
    <div className="space-y-6">
      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Revenue"
          value={`$${metrics.totalRevenue.toLocaleString()}`}
          change="+12.5%"
          isPositive={true}
          icon={<DollarSign className="h-5 w-5 text-white" />}
        />
        <MetricCard
          title="Total Expenses"
          value={`$${metrics.totalExpenses.toLocaleString()}`}
          change="+2.3%"
          isPositive={false}
          icon={<TrendingDown className="h-5 w-5 text-white" />}
        />
        <MetricCard
          title="Net Profit"
          value={`$${metrics.netProfit.toLocaleString()}`}
          change="+18.2%"
          isPositive={metrics.netProfit > 0}
          icon={<TrendingUp className="h-5 w-5 text-white" />}
        />
        <MetricCard
          title="Transactions"
          value={metrics.totalTransactions.toString()}
          change="+5.4%"
          isPositive={true}
          icon={<Users className="h-5 w-5 text-white" />}
        />
      </div>

      {/* Charts and Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RevenueChart />
        </div>
        <div>
          <RecentTransactions transactions={transactions} />
        </div>
      </div>
    </div>
  );
}