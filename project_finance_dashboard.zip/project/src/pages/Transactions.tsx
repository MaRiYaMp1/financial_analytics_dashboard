import React from 'react';
import { TransactionTable } from '../components/Transactions/TransactionTable';
import { useTransactions } from '../hooks/useTransactions';

export function Transactions() {
  const { transactions, loading, filters, updateFilters, exportToCSV } = useTransactions();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Transactions</h1>
        <p className="text-slate-400">Manage and analyze your financial transactions</p>
      </div>

      <TransactionTable
        transactions={transactions}
        filters={filters}
        onFiltersChange={updateFilters}
        onExport={exportToCSV}
        loading={loading}
      />
    </div>
  );
}